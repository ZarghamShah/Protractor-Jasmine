exports.config = {
  directConnect: true,
  capabilities: {
    'browserName': 'chrome',
    chromeOptions: {
      args: ['--start-fullscreen', '--disable-infobars',]
    }
  },
  specs: ['spec/assignment_3.js'],
  framework: 'jasmine',
  loggingPrefs: {
    'driver': 'WARNING',
    'server': 'WARNING',
    'browser': 'INFO'
  },
  params: {
    login: {
      username: 'angular',
      password: 'password'
    },
  },
  }
  
