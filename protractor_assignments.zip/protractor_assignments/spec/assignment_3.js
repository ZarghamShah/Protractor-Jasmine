var addUser_POM = require('../POM/addUser_POM')
const POM = new addUser_POM()

describe('Make ammendments in the record', function () {

    beforeAll(function () {

        browser.get('http://www.way2automation.com/angularjs-protractor/webtables/')
        var Title = browser.getTitle()
        expect(Title).toBe("Protractor practice website - WebTables")
        console.info('The titles have macthed');

    });

    it('should open the website and add a record', function () {

        expect(POM.table).toBe(7)
        POM.add_Record()
        expect(POM.table).toEqual(8)
        console.info("New data entered successfully")
        expect(POM.tableData.getText()).toEqual("Zargham")
        console.info("Entered data is verified")
    });

    it('should open the website and edit a record', function () {

        POM.edit_FirstName()
        expect(POM.tableData.getText()).toEqual("zargham")
        console.info("The First Name has been edited and verified")

    })
});