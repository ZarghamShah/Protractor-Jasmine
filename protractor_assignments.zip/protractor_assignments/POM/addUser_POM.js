module.exports = class addUser_POM {
    
    get addBTN() { return (element(by.className("btn btn-link pull-right")))}
    get addUserWindow() { return (element(by.className("modal ng-scope")))}
    get firstName() {return (element(by.name("FirstName")))}
    get lastName() {return (element(by.name("LastName")))}
    get userName() {return (element(by.name("UserName")))}
    get password() {return (element(by.name("Password")))}
    get role() {return (element(by.name("RoleId", "Sales Team")).$$('[value="1"]'))}
    get email() {return (element(by.name("Email")))}
    get cellNumber() {return (element(by.name("Mobilephone")))}
    get save() {return (element(by.className("btn btn-success")))}
    get table() {return ($("tbody").$$("tr").count())}
    get tableData() {return (element.all(by.css("tbody")).all(by.tagName("td")).get(0))}
    get editButton() {return (element.all(by.className("btn btn-link")).get(1))}

    add_Record(){

    this.addBTN.isDisplayed()
    this.addBTN.click()
    this.addUserWindow.isDisplayed()
    this.firstName.sendKeys("Zargham")
    this.lastName.sendKeys("Ahmad")
    this.userName.sendKeys("zargham")
    this.password.sendKeys("password")
    this.role.click()
    this.email.sendKeys("abc@xyz.com")
    this.cellNumber.sendKeys("0123456789")
    this.save.click()
    }

    edit_FirstName(){

        browser.sleep(3000)
        this.editButton.click()
        browser.sleep(2000)
        this.firstName.clear()
        this.firstName.sendKeys("zargham")
        this.save.click()
    }
}